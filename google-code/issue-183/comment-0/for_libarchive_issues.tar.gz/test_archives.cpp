#include "test_archives.h"



using namespace std;

void my_func(void)
{
// time-consuming code
	cout <<"start computation"<<endl;
   double sum;
   for (int i=0; i<10; i++)
   {
	   cout <<"it"<<i<<endl;
      for (int j=0; j<10000000; j++)
      {
         sum = sum * i / j;
      }
   }
   cout <<"end computation"<<endl;
}

int main() {

	cout << "hello testing" << endl;

	//tar path: /home/simon/testing/tar/packages_build/UPD_swpc5.tar.gz
	//QString inpath("/home/simon/testing/tar/packages_build/UPD_swpc5.tar.gz");
	QString inpath("./retest.tar.gz");


	QString outpath("./out");

	//testingCreateActiveDir kcrdir;
	//das ist QDOM!!
	//testingTarExtraction kt;
	//kt.extract_tar_file_to(, int do_extract, int flags, const char *outpath);


	cout <<"again"<<endl;
	testingTarExtraction kt;
	kt.extract_tar_file_to(inpath.toAscii().constData(),1,1,outpath.toAscii().constData());
	cout << "archive version: "<<ARCHIVE_VERSION_NUMBER << "version string: "<< ARCHIVE_VERSION_STRING<<endl;
	//testingTarExtraction::extract_tar_file_to(const char *filename, int do_extract, int flags, const char *outpath){
	  cout <<"finished"<<endl;


	return 0;
}


