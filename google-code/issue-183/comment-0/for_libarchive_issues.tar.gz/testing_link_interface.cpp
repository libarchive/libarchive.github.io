#include "testing_link_interface.h"


using namespace std;
int mentioned_file_already_exists;

int testing_qtlink(QString from_file, QString to_file, int updateMode) {
	int r = link(from_file.toUtf8().constData(), to_file.toUtf8().constData());

	if (r < 0) {

		if (EEXIST == errno) {
			if (updateMode == update_hard_link) {
				//replace files!!
				//delete
				if (remove(to_file.toUtf8().constData()) == -1) {
					perror("Error in deleting a file");
					cout << "Error in deleting file:" << qPrintable(to_file) << endl;
				} else {
					//cout << "deleted: "<<qPrintable(to_file) <<endl;
				}
				//recreate
				//cout <<"recreating:"<<qPrintable(from_file)<<"  "<<qPrintable(to_file)<<endl;
				testing_qtlink(from_file, to_file, updateMode);
			} else {
				//keep existing files
			}
			if (0) {
				mentioned_file_already_exists = 1;
				cout << "testing_qtlink: target file already exists!!! -  how handle that case??" << endl;
				cout << " file: " << qPrintable(from_file) << " to file: " << qPrintable(to_file) << endl;
				cout << "update mode: " << updateMode << endl;
			}
		} else {
			//cout << " file: " << cfrom_file << " to file: "<< cto_file << endl;
			cout << "link error, errno: " << errno << endl;
			printf("link error strerror: %s\n", strerror(errno));
			cout << " file: " << qPrintable(from_file) << " to file: " << qPrintable(to_file) << endl;
			//cout << " again, char:"<<cfrom_file <<" to  "<<cto_file<<endl;
		}
	}
	return 0;
}

void cstr_hardlink_copy_Folder(const char *csourceFolder, const char *cdestFolder, int update_mode) {
	QString sourceFolder = QString::fromUtf8(csourceFolder);
	QString destFolder = QString::fromUtf8(cdestFolder);
	hardlink_copy_Folder(sourceFolder, destFolder, update_mode);
}

void hardlink_copy_Folder(QString sourceFolder, QString destFolder, int update_mode) {

	//cout << "hardlink-copying folder: "<< qPrintable(sourceFolder)<< " to: " << qPrintable(destFolder) << endl;

	QDir sourceDir(sourceFolder);
	if (!sourceDir.exists()) {
		cout << "error: srcdir: " << qPrintable(sourceDir.absolutePath()) << "does not exist" << endl;
		return;
	}

	QDir destDir(destFolder);
	if (!destDir.exists()) {
		//cout << "check dir permissions from src!!, creating: "<< qPrintable(destFolder)<<endl;

		destDir.mkdir(destFolder);

		//QFile::setPermissions(destDir.absolutePath() ,QFile::permissions(sourceDir.absolutePath()));
		QFile::setPermissions(destDir.absolutePath(), QFile::permissions(sourceDir.absolutePath()));
	}

	QStringList files = sourceDir.entryList(QDir::Files);

	for (int i = 0; i < files.count(); i++) {
		QString srcName = sourceFolder + "/" + files[i];
		QString destName = destFolder + "/" + files[i];
		//instead copying: hard linking!
		//QFile::copy(srcName, destName);
		if (!QString::compare(srcName, destName, Qt::CaseSensitive)) {
			cout << "same strings!! " << endl;
		}
		testing_qtlink(srcName, destName, update_mode);
	}
	files.clear();
	files = sourceDir.entryList(QDir::AllDirs | QDir::NoDotAndDotDot);
	for (int i = 0; i < files.count(); i++) {
		QString srcName = sourceFolder + "/" + files[i];
		QString destName = destFolder + "/" + files[i];
		//recursive call:
		//cout <<" calling recursive with: srcfolder "<< qPrintable(srcName)<< "destfolder "<< qPrintable(destName) <<endl;
		hardlink_copy_Folder(srcName, destName, update_mode);

	}
}

int testing_create_dir(const char *dir_path) {
	struct stat status_buf;
	cout <<"testing_create_dir: creating directory: "<<dir_path<<endl;
	//cout << "returned : "<< stat(to_path, &status_buf) << " " << errno << "EACCES "<<EACCES << "  " << endl;
	cout <<" stat result:"<<stat(dir_path, &status_buf) <<endl;

	if (stat(dir_path, &status_buf) == -1) {
		if (errno == ENOENT) {
			//dir does not exist -> create it
			cout <<"mkdir"<<endl;
			mode_t mode =0770;
			mkdir(dir_path, mode);

		} else {
			cout << "unforeseen error in stat path: " << dir_path << " errno:= " << errno << endl;
			return -1;
		}
	} else {
		//already exists
		//there could be checked if its a dir
		//cout << "isdir: "<< S_ISDIR(status_buf.st_mode)<<endl;
		if (!S_ISDIR(status_buf.st_mode)) {
			cout << " error! to_path: " << dir_path << " already exists, but is no directory " << endl;
			return -1;
		}
		//check access rights!!

		if (access(dir_path, W_OK) < 0 || access(dir_path, X_OK) < 0) {
			//no write or read access??
			if (errno == EACCES) {
				cout << "not enough permissions to path: " << dir_path << endl;
				return -1;
			} else {
				cout << "error in checkin permission to path: " << dir_path << " errno: " << errno << endl;
				return -1;
			}
		}
	}
	return 0;
}


int testing_create_dir(QString dir_path_qstr) {
	struct stat status_buf;
	cout <<"testing_create_dir: creating directory: "<<qPrintable(dir_path_qstr)<<endl;
	//cout << "returned : "<< stat(to_path, &status_buf) << " " << errno << "EACCES "<<EACCES << "  " << endl;
	//cout <<" stat result:"<<stat(dir_path_qstr.toAscii().constData(), &status_buf) <<endl;
	//path[0] = '\0'; //reset the char array that holds the path
	//DIR *pdir=opendir(qPrintable(dir_path_qstr));

    //If the dir does not exist create it with read/write/search permissions for owner
    // and group, and with read/search permissions for others
	int ret2=5;
    //if(!pdir)
	QString manipath= dir_path_qstr;
    //ret2=mkdir(qPrintable(dir_path_qstr),  S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    ret2=mkdir(qPrintable(manipath),  S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    cout <<"created with new variant:"<<ret2<<endl;



	if (stat(dir_path_qstr.toAscii(), &status_buf) == -1) {
		return 0;
		if (errno == ENOENT) {
			//dir does not exist -> create it
			cout <<"QT mkdir:"<<dir_path_qstr.toAscii().constData()<<endl;
			mode_t mode =0770;
			QDir qdirobj;
			QFile qfileobj;
			QString cr_dir = dir_path_qstr+"/";
			QString mkdircall="mkdir "+cr_dir;
			mode_t process_mask = umask(0);
			//int ret = qdirobj.mkdir(cr_dir);
			//int ret= system(qPrintable(mkdircall));
			//qfileobj.setPermissions(cr_dir,QFile::WriteOwner|QFile::ExeOwner|QFile::ReadOwner|QFile::WriteGroup |QFile::ReadGroup |QFile::ExeGroup|QFile::ReadUser|QFile::WriteUser|QFile::ExeUser);
			umask(process_mask);
			int ret =0;
			//system()
			if (ret){
				cout <<"mkdired: "<<qPrintable(cr_dir);
			}
			else
			{
				cout <<"mkdir failed: "<<qPrintable(cr_dir);
			}

					/*
					 * QFile::ReadOwner	0x4000	The file is readable by the owner of the file.
QFile::WriteOwner	0x2000	The file is writable by the owner of the file.
QFile::ExeOwner	0x1000	The file is executable by the owner of the file.
QFile::ReadUser	0x0400	The file is readable by the user.
QFile::WriteUser	0x0200	The file is writable by the user.
QFile::ExeUser	0x0100	The file is executable by the user.
QFile::ReadGroup	0x0040	The file is readable by the group.
QFile::WriteGroup	0x0020	The file is writable by the group.
QFile::ExeGroup	0x0010	The file is executable by the group.
QFile::ReadOther	0x0004	The file is readable by anyone.
QFile::WriteOther	0x0002	The file is writable by anyone.
QFile::ExeOthe
					 */

			//mkdir(dir_path_qstr.toAscii().constData(), mode);


		} else {
			cout << "unforeseen error in stat path: " << qPrintable(dir_path_qstr) << " errno:= " << errno << endl;
			return -1;
		}
	} else {
		//already exists
		//there could be checked if its a dir
		//cout << "isdir: "<< S_ISDIR(status_buf.st_mode)<<endl;
		if (!S_ISDIR(status_buf.st_mode)) {
			cout << " error! to_path: " <<  qPrintable(dir_path_qstr) << " already exists, but is no directory " << endl;
			return -1;
		}
		//check access rights!!

		if (access(dir_path_qstr.toAscii(), W_OK) < 0 || access(dir_path_qstr.toAscii(), X_OK) < 0) {
			//no write or read access??
			if (errno == EACCES) {
				cout << "not enough permissions to path: " << qPrintable(dir_path_qstr)<< endl;
				return -1;
			} else {
				cout << "error in checkin permission to path: " << qPrintable(dir_path_qstr) << " errno: " << errno << endl;
				return -1;
			}
		}
	}
	return 0;
}


int testing_hardlink_directory(const char *from_path, const char *to_path, int update_mode) {

	cout << " linking directory from: " << from_path << " to: " << to_path << endl;
	mentioned_file_already_exists = 0;
	//create dir:
	testing_create_dir(to_path);
	//mode_t   st_mode;     /* File mode (type, perms) */

	cstr_hardlink_copy_Folder(from_path, to_path, update_mode);

	return 0;

}

