/*
 * testing_tar_interface.h
 *
 *  Created on: Apr 28, 2011
 *      Author: Simon
 */
#include "testing_tar_class.h"

using namespace std;

// finally working! using libarchive.
// On my system (Ubuntu LTS)it was necessary to get an actualized Version from the libarchive SVN - may also work with the original distributions libarchive,
// if installed version is recent enough

void testingTarExtraction::hi(){
	cout <<"hi"<<endl;
}


int testingTarExtraction::extract_tar_file_to_sys(const char *filename, int do_extract, int flags, const char *outpath){
	cout <<" testingTarExtraction::extract_tar_file_to_sys, from:"<< filename <<" to:"<<outpath<<endl;
	cout <<"a replacement for: extract_tar_file_to, until problems with directory creation are solved!"<<endl;
	QString fname(filename);
	QString outname(outpath);
	QString untar_cmd;
	testing_create_dir(outname);


	//untar_cmd="tar -xvf "+fname+" -C "+outname;
	//system(qPrintable(untar_cmd));
	untar_cmd="tar -xvf "+fname+" -C "+outname;
	int ret=system(qPrintable(untar_cmd));
	if (ret == 0){
		return 0;
	}
	else
	{
		cout <<" tar ret code: "<<ret <<endl;
	}

	return 0;
}

void testingTarExtraction::extract_tar_file_to(const char *filename, int do_extract, int flags, const char *outpath){

	cout <<" testingTarExtraction::extract_tar_file_to, from:"<< filename <<" to:"<<outpath<<endl;
	testingHelpers testinghelper_obj;
	//int fl=ARCHIVE_EXTRACT_TIME;
	struct archive *a;
	struct archive *ext;
	struct archive_entry *entry;
	int r;
	//flags = 0;
	cout <<"testingTarExtraction: overwriting flags:"<<endl;
    flags = ARCHIVE_EXTRACT_TIME;
	flags |= ARCHIVE_EXTRACT_PERM;
	flags |= ARCHIVE_EXTRACT_ACL;
	flags |= ARCHIVE_EXTRACT_FFLAGS;
	flags |= ARCHIVE_EXTRACT_OWNER;
	//flags |= ARCHIVE_ENTRY_ACL_WRITE_OWNER;

	//errmsg_tar(outpath);
	cout <<"let create dir: "<<outpath<<endl;
	QString targetpath(outpath);

	//testing_create_dir(outpath);
	testing_create_dir(targetpath);
	//assert(0);
	//QString lscall("ls /home/simon/testing/tar/testing_install/audio");
	QString lscall("ls ");
	lscall = lscall +" "+outpath;

	cout <<"created dir: "<<qPrintable(targetpath)<<endl;
	a = archive_read_new();
	ext = archive_write_disk_new();
	archive_write_disk_set_options(ext, flags);
	//archive_write_
	/*
	 * Note: archive_write_disk_set_standard_lookup() is useful
	 * here, but it requires library routines that can add 500k or
	 * more to a static executable.
	 */
	//archive_read_support_format_tar(a);
	archive_read_support_format_all(a);
	//archive_read_support_format_zip(a);
	archive_read_support_compression_all(a);

	/*
	 * Comment from original developer:
	 * On my system, enabling other archive formats adds 20k-30k
	 * each.  Enabling gzip decompression adds about 20k.
	 * Enabling bzip2 is more expensive because the libbz2 library
	 * isn't very well factored.
	 */

	if (filename != NULL && strcmp(filename, "-") == 0)
		filename = NULL;
	if ((r = archive_read_open_file(a, filename, 10240))){
		fail_tar("archive_read_open_file()", archive_error_string(a), r);
		exit (1);
		}
	for (;;)
	{

		//system(qPrintable(lscall));
		r = archive_read_next_header(a, &entry);

		if (r == ARCHIVE_EOF)
			break;

		if (r != ARCHIVE_OK){
			cout <<"before_out"<<endl;
			fail_tar("archive_read_next_header()", archive_error_string(a), 1);
		}
		if (r < ARCHIVE_WARN){
			cout <<"r < ARCHIVE_WARN"<<endl;
		      exit(1);
		}

		if (tar_verbose && do_extract)
			msg_tar("x ");
		//if (tar_tar_verbose || !do_extract)

		QString prep_out;
		cout <<"curr name: "<<archive_entry_pathname(entry) <<endl;
		cut_path_front(archive_entry_pathname(entry),&prep_out);
		cout <<"prep out: "<<qPrintable(prep_out)<<endl;
		QString combined = QString::fromUtf8(outpath) +"/"+ prep_out;

		//QString matchpattern = ".*dahin.*";
		//const char *final_path_out = combined.toAscii().constData();
		//archive_entry_set_pathname(entry, final_path_out);

		archive_entry_set_pathname(entry, combined.toAscii().constData());

		//msg_tar("-------");
		//msg_tar(archive_entry_pathname(entry));
		//cout << "to: "<<(archive_entry_pathname(entry))<<endl;

		/*
		if ( !testinghelper_obj.regxp_filter_line(QString::fromUtf8(archive_entry_pathname(entry)), matchpattern) )
		{
			cout << "no match: "<<qPrintable(QString::fromUtf8(archive_entry_pathname(entry))) << "  pattern:  "<< qPrintable(matchpattern) <<endl;
			cout << "was:"<< qPrintable(combined)<< endl;
		}

		*/
		cout << "extracting to: "<< qPrintable(combined)<< endl;

		if (do_extract) {
			//cout <<"current dirview 6"<<endl;
			//system(qPrintable(lscall));
			r = archive_write_header(ext, entry);
			//cout <<"current dirview 7"<<endl;
			//system(qPrintable(lscall));
			if (r != ARCHIVE_OK) {
				mode_t archmode;
				archmode = archive_entry_filetype(entry);
				cout << "archive mode: " << S_ISDIR(archmode) << endl;
				warn_tar("archive_write_header()", archive_error_string(ext));
				assert(0);
			} else {

				if (archive_entry_size(entry) > 0) {
					copy_data(a, ext);

					//mode_t archmode;
					//archmode = archive_entry_filetype(entry);

					//if (!S_ISDIR(archmode)){
					//copy_data(a, ext);
					//}
					if (r != ARCHIVE_OK)
						fprintf(stderr, "%s\n", archive_error_string(ext));
					if (r < ARCHIVE_WARN)
						assert(0);
				}
				r = archive_write_finish_entry(ext);


				if (r != ARCHIVE_OK) {
					fail_tar("archive_write_finish_entry()",
							archive_error_string(ext), 1);
				}

				//archive_write_close(ext);
				if (r < ARCHIVE_WARN)
					assert(0);
			}
		}
		//free (final_path);
		//if (tar_verbose || !do_extract)
		//msg_tar("\n");
	}
	archive_read_close(a);

	archive_read_finish(a);
	archive_write_close(ext);
	archive_write_finish(ext);
	//archive_write_free(ext);

	//exit(0);
}

void testingTarExtraction::cut_path_front (const char *path, QString *pathout ){
	//cout << " cut path front: "<<path << endl;
	QString pathx = QString::fromUtf8(path);
	if ( pathx.startsWith("./") )
			{
			//cout << "a ./path:"<< qPrintable( pathx) <<endl;
		     //QString x = "Say yes!";
		     QString y = "/";
		     pathx.replace(0, 2, y);
		     //cout << "a ./path:"<< qPrintable( pathx) <<endl;
		     // x == "Say no!"
		     //const char *cdestName = destName.toUtf8().constData();
		     //path=pathx.toUtf8().constData();
		     *pathout=pathx;
		     *pathout="replacement should no more be used!";
		     cout << "result of convert"<<qPrintable(*pathout) << endl;


			}
	else{
		*pathout=pathx;
	}

}

int testingTarExtraction::copy_data(struct archive *ar, struct archive *aw){
	int r;
		const void *buff;
		size_t size;
#if  (ARCHIVE_VERSION_NUMBER < 3000000)
		off_t offset;
#endif
#if (ARCHIVE_VERSION_NUMBER >= 3000000)
		int64_t offset;
#endif

		for (;;) {
			//r = archive_read_data_block()
			r = archive_read_data_block(ar, &buff, &size, &offset);
			if (r == ARCHIVE_EOF)
				return (ARCHIVE_OK);
			if (r != ARCHIVE_OK){
				cout <<"r != ARCHIVE_OK"<<endl;
				assert(0);
				return (r);
			}
			r = archive_write_data_block(aw, buff, size, offset);
			if (r != ARCHIVE_OK) {
				warn_tar("archive_write_data_block()",
				    archive_error_string(aw));
				cout <<"warn copy_data"<<endl;
				return (r);
			}
		}
}

/*
 * These reporting functions use low-level I/O; on some systems, this
 * is a significant code reduction.  Of course, on many server and
 * desktop operating systems, malloc() and even crt rely on printf(),
 * which in turn pulls in most of the rest of stdio, so this is not an
 * optimization at all there.  (If you're going to pay 100k or more
 * for printf() anyway, you may as well use it!)
 *
 * --> they are from the libarchive example. Eliminate them by using cout or DLT
 */


	//static int	copy_data(struct archive *, struct archive *);
void testingTarExtraction::msg_tar(const char *m){
	write(1, m, strlen(m));
}
void testingTarExtraction::errmsg_tar(const char *m)
{
	write(2, m, strlen(m));
}

	//static void	usage(void);
void testingTarExtraction::warn_tar(const char *f, const char *m){
	errmsg_tar(f);
	errmsg_tar(" failed: ");
	errmsg_tar(m);
	errmsg_tar("\n");
}
void testingTarExtraction::fail_tar(const char *f, const char *m, int r){
	warn_tar(f, m);
	exit(r);
}

