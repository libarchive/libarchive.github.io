#ifndef testing_HELPERS_H_
#define testing_HELPERS_H_

#include <stdio.h>    //FILE, fopen(), fclose()
#include <sys/stat.h> //stat, stat()
#include <string>     //string
#include <fstream>    //fstream
#include <iostream>   //cout
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <QtCore/QObject>
#include <qstring.h>
#include <QtCore/qstringlist.h>
#include <QRegExp>
#include <sys/sysinfo.h>
#include <stdlib.h>
//#include "../testingAgentIncludes.h"


using namespace std;

int getdir(QString dir, vector<dirent> &files);
int getdir(QString dir, vector<dirent> &files, QString type);


enum Etesting_State { EXTRACT, INSTALL, LINKING, IDLE, SWIPCHECK };
enum ESWIP_State { INSTALL_POSSIBLE, NO_INSTALL, CHECKING, NOT_SET};

struct mount_point_status {
	bool mounted;
	QString mount_to_path;
	QString mount_from_path;
	bool in_use;
};


struct install_data{
	QString version;
	QString path;
	QString parent_path;
	QString tar_src_path;//path of the tar in the mount directory -> for extraction!
	QString category;
	QString info_path;
	QString install_type;
	int install_ctr;
	int allow_delete;
};


class testingHelpers {

public:

	QString kh_testing_install_directory;

	//kh_testing_install_directory
	testingHelpers() {
		kh_testing_install_directory="None";
	}

	testingHelpers(QString install_dir) {
		cout <<"initializing testingHelpers with: "<<qPrintable(install_dir)<<endl;
			kh_testing_install_directory=install_dir;
		}

	void set_install_directory(QString install_dir) {
		cout <<"initializing testingHelpers with: "<<qPrintable(install_dir)<<endl;
			kh_testing_install_directory=install_dir;
		}

	bool OpenCppFileExists(const QString& filename) {
		fstream fin;
		//this will fail if more capabilities to read the
		//contents of the file is required (e.g. \private\...)
		//fin.open(filename.c_str(), ios::in);
		//fin.open(filename.toStdString().c_str() , ios::in);
		fin.open(filename.toAscii(), ios::in);

		if (fin.is_open()) {
			fin.close();
			return true;
		}
		fin.close();

		return false;
	}

	int recursive_delete_directory_path(QString path,bool subdirs_only){
		cout <<"recursive_delete_directory_path: "<<qPrintable(path)<<" subdirs only?:"<<bool(subdirs_only)<<endl;

		if (path.right(1).compare("/")){
			//does not end with a "/"
			path=path+"/";
		}
		if (subdirs_only){
			path=path+"*";
		}
		QString rm_command="rm -R "+path;
		cout <<"rm command:"<<qPrintable(rm_command)<<endl;
		int ret = system(qPrintable(rm_command));
		if (ret != 0){
			cout <<"some error with deleting files in path:!!"<<qPrintable(path)<<endl;
		}

		return 0;

	}

	int free_mem_kb(){
		  struct sysinfo si;
		  sysinfo (&si);
		//std::cout <<"ram free: "<< si.freeram*si.mem_unit/1024<<std::endl;
		  int free = si.freeram*si.mem_unit/1024;
		  return free;
	}

	//int getdir(QString dir, vector<string> &files) {
	int getdir(QString dir, vector<dirent> &files) {
		cout <<"getdir: "<<qPrintable(dir)<<endl;
		//return a list with directory content
		DIR *dp;
		struct dirent *dirp;
		if ((dp = opendir(dir.toAscii())) == NULL) {
			cout << "Error(" << errno << ") opening " << qPrintable(dir) << endl;
			return errno;
		}
		//cout <<"testinghelper.getdir 1 : Type:"<< dp->d_type <<endl;
		int i = 0;
		while ((dirp = readdir(dp)) != NULL) {
			i++;
			/*
			if (dirp->d_type == DT_REG)
				cout <<"its a regular file!"<<endl;
			if (dirp->d_type == DT_DIR)
							cout <<"its a regular directory!"<<endl;
							*/
			if (dirp->d_type != DT_DIR && dirp->d_type != DT_REG){
				//cout <<"testinghelper.getdir :its a something else! Type:"<<dirp->d_type <<endl;
				//cout << dirp->d_name<<endl;
			}
			else{
				//cout << "coorect?"<<dirp->d_name<<endl;
			}


			//cout << " content: "<< dirp->d_name <<endl;
			//files.push_back(string(dirp->d_name));
			files.push_back(*dirp);
		}
		closedir(dp);
		return 0;
	}

	int getdir(QString dir, vector<dirent> &files, QString type) {
			//return a list with directory content
			cout <<"getdir2"<<qPrintable(dir)<<endl;
			DIR *dp;
			struct dirent *dirp;
			if ((dp = opendir(dir.toAscii())) == NULL) {
				cout << "Error(" << errno << ") opening " << qPrintable(dir) << endl;
				return errno;
			}
			int i = 0;
			while ((dirp = readdir(dp)) != NULL) {
				i++;
				/*
				if (dirp->d_type == DT_REG)
					cout <<"its a regular file!"<<endl;
				if (dirp->d_type == DT_DIR)
								cout <<"its a regular directory!"<<endl;
								*/
				if (dirp->d_type != DT_DIR && dirp->d_type != DT_REG)
					cout <<"testinghelper.getdir :its a something else!"<<endl;


				//cout << " content: "<< dirp->d_name <<endl;
				//files.push_back(string(dirp->d_name));
				if ((!type.compare("file") && dirp->d_type == DT_REG) || ( !type.compare("dir") && dirp->d_type == DT_DIR && QString::compare(".",dirp->d_name) && QString::compare("..",dirp->d_name)) )
				{
					cout << " pushing back: "<< dirp->d_type << "recheck: "<<DT_DIR<< " name: "<< dirp->d_name << "type: "<<qPrintable(type)<<endl;
					files.push_back(*dirp);
				}
			}
			closedir(dp);
			return 0;
		}




	void print_fileslist(vector<dirent> &files) {
		cout << "testing helper print_fileslist" << endl;
		for (uint i = 0; i < files.size(); i++) {
			if (files[i].d_type == DT_REG) {
				cout << "elem "<<i<<": " << string(files[i].d_name) << endl;
			}
		}
	}

	int regxp_filter_line(QString line,QString matchpattern)
	{
		QRegExp rx(matchpattern);
		if (! rx.isValid())
		{
			cout << "invalid matchpattern!"<<endl;
			return -1;
		}

		if (rx.exactMatch(line))
		{
			return 1;
		}
		else
		{
			return 0;
		}

	}

	int filter_fileslist(vector<dirent> &files,vector<dirent> &result_fileslist, QString matchpattern) {
		QRegExp rx(matchpattern);
		if (! rx.isValid())
			return 1;

		cout << "listing files in list" << endl;
		for (uint i = 0; i < files.size(); i++) {
			if (files[i].d_type == DT_REG) {
				QString filename(files[i].d_name);
				if (rx.exactMatch(filename))
				{
					cout << "elem matches::" << string(files[i].d_name) << endl;
					result_fileslist.push_back(files[i]);

				}

			}
		}
		return 0;
	}

	int swip_line_to_install_data(QStringList *stringlist, install_data *inst_data, QString swip_parent_path) {
		cout << "input line, install data -- will be replaced by some xml parser!"<<stringlist->size() << endl;
		cout <<" stringlist1 :" << qPrintable(stringlist->at(1));
		cout <<" stringlist0 :" << qPrintable(stringlist->at(0));
		if (stringlist->size() > 2) {
			cout << "size of line is ok" << endl;
			cout <<" stringlist:" << qPrintable(stringlist->at(1));
			inst_data->version = stringlist->at(1);
			inst_data->category = stringlist->at(0);
			//inst_data->path = stringlist->at(2);
			//kh.kh_testing_install_directory
			if (kh_testing_install_directory.compare(QString("None")) != 0 ){
			inst_data->path = kh_testing_install_directory + "/" + inst_data->category + "/" + inst_data->category +"_" +inst_data->version;
			cout <<"composed install directory "<<qPrintable(inst_data->path);
			}
			else
			{
				cout <<"swip_line_to_install_data warning: no kh_testing_install_directory set!:"<<qPrintable(kh_testing_install_directory)<<endl;
				cout <<kh_testing_install_directory.compare(QString("None"))<<endl;
				inst_data->path = "None";
			}
			inst_data->tar_src_path = swip_parent_path+"/"+ stringlist->at(2);
		}
		return 0;
	}








};
#endif /* testing_HELPERS_H_ */
