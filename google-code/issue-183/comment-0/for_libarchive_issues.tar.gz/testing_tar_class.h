/*
 * testing_tar_interface.h
 *
 *  Created on: Apr 28, 2011
 *      Author: Simon
 */

#ifndef testing_TAR_CLASS_TMP_H_
#define testing_TAR_CLASS_TMP_H_
//#pragma once

//#include <archive.h>
#include <archive.h>
#include <iostream>
#include <QString>
#include <assert.h>

#include <sys/types.h>
//__FBSDID("$FreeBSD$");
#include <sys/stat.h>
#include <archive_entry.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "testing_link_interface.h"
#include <qstring.h>
#include "testing_helpers.h"
//#include <libtar.h>




using namespace std;


class testingTarExtraction{
public:

	testingTarExtraction() {
		tar_verbose=0;
	}

public:
	void hi();
	void	errmsg_tar(const char *m);
	void	extract_tar_file_to(const char *filename, int do_extract, int flags, const char *outpath);

	//extract_tar_file_to_sys does not use libarchive!! it is just faking, and using the tar sys command!
	int  	extract_tar_file_to_sys(const char *filename, int do_extract, int flags, const char *outpath);
	void	extract_tar_file_to_ltar(const char *filename, int do_extract, int flags, const char *outpath);


	//private: //TODO
	void cut_path_front (const char *path, QString *pathout );
	int copy_data(struct archive *ar, struct archive *aw);

	void	fail_tar(const char *, const char *, int);
	//static int	copy_data(struct archive *, struct archive *);
	void	msg_tar(const char *m);
	//static void	usage(void);
	void	warn_tar(const char *f, const char *m);


	int tar_verbose;
};

//void extract_file_to(char* path, char* destination_path);


//taken from libtar example: untar.c

/*
 * This file was in the public domain. Author Stated: * Use it as you wish.
 */


/*
	switch (mode) {
	case 't':
		extract(filename, 0, flags,outpath);
		break;
	case 'x':
		extract(filename, 1, flags,outpath);

*/

/*about the flags:
 *
 * default:
 * flags = ARCHIVE_EXTRACT_TIME;
 *                        case 'p':
                                flags |= ARCHIVE_EXTRACT_PERM;
                                flags |= ARCHIVE_EXTRACT_ACL;
                                flags |= ARCHIVE_EXTRACT_FFLAGS;
 *
 */



#endif /* testing_TAR_INTERFACE_H_ */
