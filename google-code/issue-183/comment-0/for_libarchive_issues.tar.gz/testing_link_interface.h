//#ifndef testing_LINK_INTERFACE_H_
//#define testing_LINK_INTERFACE_H_
#pragma once
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <QFile>
#include <QFileInfo>
#include <QDir>
#include <qstring.h>
#include <iostream>
#include <dirent.h>


#define update_hard_link 1
#define keep_hard_link 2
using namespace std;

//int mentioned_file_already_exists;


int testing_qtlink (QString from_file, QString to_file, int updateMode);
void hardlink_copy_Folder(QString csourceFolder, QString cdestFolder,int update_mode);
void cstr_hardlink_copy_Folder(const char *csourceFolder, const char *cdestFolder,int update_mode);
int testing_create_dir(const char *dir_path);
int testing_create_dir(QString dir_path_qstr);
int testing_hardlink_directory(const char *from_path, const char *to_path, int methods);



//#endif /* testing_LINK_INTERFACE_H_ */
