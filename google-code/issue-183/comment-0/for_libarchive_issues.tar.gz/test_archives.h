/*
 * test.h
 *
 *  Created on: Apr 6, 2011
 *      Author: Simon
 */

#ifndef TEST_H_
#define TEST_H_
//#include <QApplication>
//#include <QPushButton>
#include "testing_tar_class.h"
#include <QThread>
#include <assert.h>
//#include <QHBoxLayout>
//#include <QMessageBox>
#include <QtConcurrentRun>
#include <QFuture>
#include <QFile>
#include <QFutureWatcher>
#include "testing_tar_class.h"
#include "testing_helpers.h"
#include "testing_link_interface.h"
//#include "testing_create_active_directory_class.h"
#include <QtXml/QXmlSimpleReader>
#include <QtXml/QXmlInputSource>
#include <QtXml/QXmlErrorHandler>
#include <QtXml/QXmlContentHandler>
//#include "qc14n.h"
//#include <QtXml/QDomDocument>
//#include <QtXml/QDomElement>
//#include <QtXml/QDomText>


#include <iostream>

//#include "testing_create_active_directory.h"
//#include "testing_create_active_directory_class.h"

void my_func(void);

/*
class testclass : public QApplication
{
   Q_OBJECT

   public:
      void start();

   private:
      //QPushButton *runButton;
      QFuture<void> *future;
      QFutureWatcher<void> *watcher;

   public slots:
      void run_thread();
      void displayFinishedBox();
};
*/
#endif /* TEST_H_ */
